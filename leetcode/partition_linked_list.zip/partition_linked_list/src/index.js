// 实现一个链表 数据存储特征是链表格式

import LinkedList from './LinkedList';
// 实例化
const list = new LinkedList();
// 形成一个链表
list
    .append(1)
    .append(4)
    .append(3)
    .append(2)
    .append(5)
    .append(2)
    console.log(list.toString())